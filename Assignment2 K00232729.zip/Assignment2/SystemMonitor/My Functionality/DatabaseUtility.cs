﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    public class DatabaseUtility : IInsert, IRead
    {
        public void Insert(string content)
        {
            // insert to database
        }

        public void Read(int Staff_id)
        {
            // read from database
        }
    }
}
