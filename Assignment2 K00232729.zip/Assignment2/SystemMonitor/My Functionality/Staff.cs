﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    public class Staff: IReport, IDatabase
    {
        public int Staff_Id { get; set; }

        private IAdminNotifier admin;
        private IReportGenerator repGen;
        private IRead dbRead;
        private IInsert dbInsert;

        public Staff()
        {

        }

        public Staff(IAdminNotifier notifier, IReportGenerator report, IRead read, IInsert insert)
        {
            admin = notifier;
            repGen = report;
            dbRead = read;
            dbInsert = insert;
        }

        public void InsertToDatabase(string report)
        {
            try
            {
                // insert to database
                dbInsert.Insert(report);
            }
            catch (Exception ex)
            {
                admin.AdminNotification("Insert database functionality is not working correctly for  due to " + ex.Message);
            }
        }
        public virtual string GenerateReport(string StaffType)
        {
            string report = "";
                try
                {
                    repGen.GeneragingReport(StaffType);
                    report = "report generated successfully";
                }
                catch (Exception ex)
                {
                Console.WriteLine(ex.Message);
                    admin.AdminNotification("Report generation functionality is not working correctly for due to " + ex.Message);

                }
            return report;

        }

        public void Read(int Staff_id)
        {
            try
            {
                // read from database
                dbRead.Read(Staff_id);
            }
            catch (Exception ex)
            {
                admin.AdminNotification("Read database functionality is not working correctly for  due to " + ex.Message);
            }
        }
    }

}
