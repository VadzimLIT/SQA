﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    public class Manager: Staff
    {
        private IReportGenerator repGen;
        private IAdminNotifier adminNotifier;
        public Manager(IReportGenerator report, IAdminNotifier admin)
        {
            repGen = report;
            adminNotifier = admin;
        }
        public override string GenerateReport(string TypeManager)
        {
            try
            {
                return repGen.GeneragingReport("Generate Report For Manager");
            }
            catch(Exception ex)
            {
                adminNotifier.AdminNotification("Error Manager Report Generation " + ex.Message);
            }
            return "Report Generated Result";
        }
    }
}
