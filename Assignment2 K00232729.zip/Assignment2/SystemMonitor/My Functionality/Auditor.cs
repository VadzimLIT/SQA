﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    public class Auditor:IReport, IRead
    {
        private IAdminNotifier adminNotifier;
        private IReportGenerator repGen;
        private IRead dbRead;

        public Auditor(IAdminNotifier notifier, IReportGenerator report, IRead read)
        {
            adminNotifier = notifier;
            repGen = report;
            dbRead = read;
        }
        public string GenerateReport(string Auditor)
        {
            try{
            return repGen.GeneragingReport(Auditor);
            }
            catch(Exception ex){
                adminNotifier.AdminNotification(" Error Auditor Report Generation " + ex.Message);
            }
            return "report generation complete";
        }

        public void Read(int Staff_id)
        {
            try
            {
                // admin notified about read from database activity
                dbRead.Read(Staff_id);
            }
            catch (Exception ex)
            {
                adminNotifier.AdminNotification("Error Auditor Read Functionality " + ex.Message);
            }
        }
    }
}
