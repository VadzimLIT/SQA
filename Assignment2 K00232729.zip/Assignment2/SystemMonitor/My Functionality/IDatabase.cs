﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    public interface IDatabase: IRead
    {
        void InsertToDatabase(string report);        
    }
}
