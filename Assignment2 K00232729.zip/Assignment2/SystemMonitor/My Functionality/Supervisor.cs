﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    public class Supervisor : Staff
    {
        private IReportGenerator repGen;
        private IAdminNotifier adminNotifier;
        public Supervisor(IReportGenerator report, IAdminNotifier admin)
        {
            repGen = report;
            adminNotifier = admin;
        }
        public override string GenerateReport(string TypeSupervisor)
        {
            try
            {
                return repGen.GeneragingReport("Generate Report For Supervisor");
            }
            catch (Exception ex)
            {
                adminNotifier.AdminNotification("Error Supervisor Report Generation " + ex.Message);
            }
            return "Report Generated Result";
        }
    }
}
