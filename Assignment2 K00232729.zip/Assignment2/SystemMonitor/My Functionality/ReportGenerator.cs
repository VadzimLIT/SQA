﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    public class ReportGenerator : IReportGenerator
    {
        public string GeneragingReport(string Staff_Type)
        {
            throw new NotImplementedException();
        }
    }
}
