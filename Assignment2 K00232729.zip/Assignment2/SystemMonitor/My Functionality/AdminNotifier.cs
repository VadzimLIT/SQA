﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    class AdminNotifier:IAdminNotifier
    {
        public void AdminNotification(String exception_context)
        {
             // functionality of this methond notifyes admin if database functionality throws exception
        }
    }
}
