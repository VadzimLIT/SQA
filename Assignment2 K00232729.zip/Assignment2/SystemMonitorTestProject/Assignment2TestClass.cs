﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment2;
using NUnit.Framework;


namespace Assignment2TestProject
{
    [TestFixture]
    class Assignment2TestClass
    {

        // ******************************************************************** TESTS FOR STAFF START ***************************************************************************************

        [Test]
        public void Staff_InsertToDatabaseForRegularEmployee_Works_Correctly()
        {   //Arrange
            FakeReportGenerator fakeReportGenerator = new FakeReportGenerator();
            FakeDatabaseUtility fakeDatabaseUtilityInsert = new FakeDatabaseUtility();
            FakeDatabaseUtility fakeDatabaseUtilityRead = new FakeDatabaseUtility();
            FakeAdminNotifier fakeAdminNotifier = new FakeAdminNotifier();
            Staff staff = new Staff(fakeAdminNotifier, fakeReportGenerator, fakeDatabaseUtilityRead, fakeDatabaseUtilityInsert);

            // Act
            staff.InsertToDatabase("Employee Report Content Insert to Database");

            // Assert 
            StringAssert.Contains("Employee Report Content Insert to Database", fakeDatabaseUtilityInsert.theMessage);
            // This test is about checking the AdminNotifier is not called in employee inserttodatabase method
            Assert.IsNull(fakeAdminNotifier.theMessage);
        }

        [Test]
        public void Staff_InsertToDatabaseForRegularEmployee_ThrowsException()
        {
            // Arrange
            FakeReportGenerator fakeReportGenerator = new FakeReportGenerator();
            FakeDatabaseUtility stubDatabaseUtilityInsert = new FakeDatabaseUtility();
            FakeDatabaseUtility fakeDatabaseUtilityRead = new FakeDatabaseUtility();
            FakeAdminNotifier fakeAdminNotifier = new FakeAdminNotifier();
            stubDatabaseUtilityInsert.WillThrow = new Exception("fake exception");
            Staff staff = new Staff(fakeAdminNotifier, fakeReportGenerator, fakeDatabaseUtilityRead, stubDatabaseUtilityInsert);

            // Act
            staff.InsertToDatabase("Employee Report Content Insert to Database");

            // Assert 
            StringAssert.Contains("Insert database functionality is not working correctly for  due to fake exception", fakeAdminNotifier.theMessage);
        }

        [Test]
        public void Staff_ReadFromDatabase_ForRegularEmployee_Works_Correctly()
        {
            //Arrange
            FakeReportGenerator fakeReportGenerator = new FakeReportGenerator();
            FakeDatabaseUtility fakeDatabaseUtilityInsert = new FakeDatabaseUtility();
            FakeDatabaseUtility fakeDatabaseUtilityRead = new FakeDatabaseUtility();
            FakeAdminNotifier fakeAdminNotifier = new FakeAdminNotifier();
            Staff staff = new Staff(fakeAdminNotifier, fakeReportGenerator, fakeDatabaseUtilityRead, fakeDatabaseUtilityInsert);

            // Act
            staff.Read(2);

            // Assert 
            Assert.AreEqual(2, fakeDatabaseUtilityRead.staffId);
            // This test is about checking the AdminNotifier is not called in employee inserttodatabase method
            Assert.IsNull(fakeAdminNotifier.theMessage);
        }

        [Test]
        public void Staff_ReadFromDatabase_ForRegularEmployee_ThrowsException()
        {
            //Arrange
            FakeReportGenerator fakeReportGenerator = new FakeReportGenerator();
            FakeDatabaseUtility fakeDatabaseUtilityInsert = new FakeDatabaseUtility();
            FakeDatabaseUtility stubDatabaseUtilityRead = new FakeDatabaseUtility();
            FakeAdminNotifier fakeAdminNotifier = new FakeAdminNotifier();
            stubDatabaseUtilityRead.WillThrow = new Exception("fake exception");
            Staff staff = new Staff(fakeAdminNotifier, fakeReportGenerator, stubDatabaseUtilityRead, fakeDatabaseUtilityInsert);

            // Act
            staff.Read(2);

            // Assert 
            StringAssert.Contains("Read database functionality is not working correctly for  due to fake exception", fakeAdminNotifier.theMessage);
        }

        [Test]
        public void Staff_GenerateReportCallCorrectlyForRegularEmployee()
        {
            // Arrange
            FakeReportGenerator fakeReportGenerator = new FakeReportGenerator();
            FakeDatabaseUtility fakeDatabaseUtilityInsert = new FakeDatabaseUtility();
            FakeDatabaseUtility fakeDatabaseUtilityRead = new FakeDatabaseUtility();
            FakeAdminNotifier fakeAdminNotifier = new FakeAdminNotifier();

            Staff staff = new Staff(fakeAdminNotifier, fakeReportGenerator, fakeDatabaseUtilityRead, fakeDatabaseUtilityInsert);// inject fakes
            staff.GenerateReport("Staff Type Employee");
            // This test is about checking that the ReportGenerator called so we are 'asking' the fake 'were you called?'
            StringAssert.Contains("Staff Type Employee", fakeReportGenerator.staffType);
        }

        [Test]
        public void Staff_GenerateReport_NotCalling_AdminNotifierForRegularEmployee()
        {
            // Arrange
            FakeReportGenerator fakeReportGenerator = new FakeReportGenerator();
            FakeDatabaseUtility fakeDatabaseUtilityInsert = new FakeDatabaseUtility();
            FakeDatabaseUtility fakeDatabaseUtilityRead = new FakeDatabaseUtility();
            FakeAdminNotifier fakeAdminNotifier = new FakeAdminNotifier();
            
            Staff staff = new Staff(fakeAdminNotifier, fakeReportGenerator, fakeDatabaseUtilityRead, fakeDatabaseUtilityInsert);// inject fakes
            // Act
            staff.GenerateReport("Staff Type Employee");
            // Assert
            // This test is about checking the AdminNotifier is not called
            Assert.IsNull(fakeAdminNotifier.theMessage);
        }

        [Test]
        public void Staff_GenerateReport_For_ValidEmployeeReport_ThrowsException_CallsAdminNotifier()
        { //Want to test that if the Staff GenerateReport throws an exception then the AdminNotifier is called correctly so its an interaction test.
          // This test needs one stub and one mock. Assert against the mock. 
          // Arrange
            FakeReportGenerator stubReportGenerator = new FakeReportGenerator();
            FakeDatabaseUtility fakeDatabaseUtilityInsert = new FakeDatabaseUtility();
            FakeDatabaseUtility fakeDatabaseUtilityRead = new FakeDatabaseUtility();
            FakeAdminNotifier fakeAdminNotifier = new FakeAdminNotifier();
            stubReportGenerator.WillThrow = new Exception("fake exception"); // prime it with a fake exception 
            Staff staff = new Staff(fakeAdminNotifier, stubReportGenerator, fakeDatabaseUtilityRead, fakeDatabaseUtilityInsert);
            
            // Act
            staff.GenerateReport("Employee Report");

            // Assert 
            StringAssert.Contains("Report generation functionality is not working correctly for due to fake exception", fakeAdminNotifier.theMessage);
        }

        // ************************************************************* TESTS FOR STAFF END *************************************************************************************************

        // ************************************************************* TESTS FOR AUDITOR START ***************************************************************************************************
        [Test]
        public void Auditor_GenerateReport_Works_Correctly()
        {   //Arrange
            FakeReportGenerator fakeReportGenerator = new FakeReportGenerator();
            FakeDatabaseUtility fakeDatabaseUtilityRead = new FakeDatabaseUtility();
            FakeAdminNotifier fakeAdminNotifier = new FakeAdminNotifier();
            Auditor auditor = new Auditor(fakeAdminNotifier, fakeReportGenerator, fakeDatabaseUtilityRead);

            // Act
            auditor.GenerateReport("Auditor Type");

            // Assert 
            StringAssert.Contains("Auditor Type", fakeReportGenerator.staffType);
            // This test is about checking the AdminNotifier is not called in employee inserttodatabase method
            Assert.IsNull(fakeAdminNotifier.theMessage);
        }

        [Test]
        public void Auditor_GenerateReport_ThrowsException()
        {   //Arrange
            FakeReportGenerator stubReportGenerator = new FakeReportGenerator();
            FakeDatabaseUtility fakeDatabaseUtilityRead = new FakeDatabaseUtility();
            FakeAdminNotifier fakeAdminNotifier = new FakeAdminNotifier();
            stubReportGenerator.WillThrow = new Exception("fake exception");
            Auditor auditor = new Auditor(fakeAdminNotifier, stubReportGenerator, fakeDatabaseUtilityRead);

            // Act
            auditor.GenerateReport("Auditor Type");

            // Assert 
            StringAssert.Contains("Error Auditor Report Generation fake exception", fakeAdminNotifier.theMessage);
        }

        [Test]
        public void Auditor_Read_Works_Correctly()
        {   // Arrange
            FakeReportGenerator fakeReportGenerator = new FakeReportGenerator();
            FakeDatabaseUtility fakeDatabaseUtilityRead = new FakeDatabaseUtility();
            FakeAdminNotifier fakeAdminNotifier = new FakeAdminNotifier();
            Auditor auditor = new Auditor(fakeAdminNotifier, fakeReportGenerator, fakeDatabaseUtilityRead);

            // Act
            auditor.Read(1234);

            // Assert 
            Assert.AreEqual(1234, fakeDatabaseUtilityRead.staffId);
            // This test is about checking the AdminNotifier is not called in employee inserttodatabase method
            Assert.IsNull(fakeAdminNotifier.theMessage);
        }

        [Test]
        public void Auditor_Read_ThrowsException()
        {   // Arrange
            FakeReportGenerator fakeReportGenerator = new FakeReportGenerator();
            FakeDatabaseUtility stubDatabaseUtilityRead = new FakeDatabaseUtility();
            FakeAdminNotifier fakeAdminNotifier = new FakeAdminNotifier();
            stubDatabaseUtilityRead.WillThrow = new Exception("fake exception");
            Auditor auditor = new Auditor(fakeAdminNotifier, fakeReportGenerator, stubDatabaseUtilityRead);

            // Act
            auditor.Read(1234);

            // Assert 
            StringAssert.Contains("Error Auditor Read Functionality fake exception", fakeAdminNotifier.theMessage);
        }
        //************************************************************************** END AUDITOR'S TEST *************************************************************************************

        //************************************************************************** START MANAGER TEST *************************************************************************************
        [Test]
        public void Manager_GenerateReport_Works_Correctly()
        {   // Arrange
            FakeReportGenerator fakeReportGenerator = new FakeReportGenerator();
            FakeAdminNotifier fakeAdminNotifier = new FakeAdminNotifier();

            Staff manager = new Manager(fakeReportGenerator, fakeAdminNotifier);
            // Act
            manager.GenerateReport("Manager");

            // Assert 
            StringAssert.Contains("Manager", fakeReportGenerator.staffType);
        }

        [Test]
        public void Manager_GenerateReport_Works_Correctly_AdminNotification_Not_Called()
        {   // Arrange
            FakeReportGenerator fakeReportGenerator = new FakeReportGenerator();
            FakeAdminNotifier fakeAdminNotifier = new FakeAdminNotifier();

            Staff manager = new Manager(fakeReportGenerator, fakeAdminNotifier);
            // Act
            manager.GenerateReport("Manager");

            // Assert 
            Assert.IsNull(fakeAdminNotifier.theMessage);
        }

        [Test]
        public void Manager_GenerateReport_Works_Throws_Excetpion()
        {   // Arrange
            FakeReportGenerator stubReportGenerator = new FakeReportGenerator();
            FakeReportGenerator fakeReportGenerator = new FakeReportGenerator();
            FakeAdminNotifier fakeAdminNotifier = new FakeAdminNotifier();
            stubReportGenerator.WillThrow = new Exception("fake exception");
            Staff manager = new Manager(stubReportGenerator, fakeAdminNotifier);
            // Act
            manager.GenerateReport("Manager");
            // Assert 
            StringAssert.Contains("Error Manager Report Generation fake exception", fakeAdminNotifier.theMessage);
            Assert.IsNull(fakeReportGenerator.staffType);
        }
        //***************************************************************** END MANAGER TESTS ************************************************************************************************

        // ***************************************************************** START SUPERVISOR FUNCTIONALITY TESTS ********************************************************************************************
        [Test]
        public void Supervisor_GenerateReport_Works_Correctly()
        {   // Arrange
            FakeReportGenerator fakeReportGenerator = new FakeReportGenerator();
            FakeAdminNotifier fakeAdminNotifier = new FakeAdminNotifier();

            Staff supervisor = new Supervisor(fakeReportGenerator, fakeAdminNotifier);
            // Act
            supervisor.GenerateReport("Supervisor");

            // Assert 
            StringAssert.Contains("Supervisor", fakeReportGenerator.staffType);
        }

        [Test]
        public void Supervisor_GenerateReport_Works_Correctly_AdminNotification_Not_Called()
        {   // Arrange
            FakeReportGenerator fakeReportGenerator = new FakeReportGenerator();
            FakeAdminNotifier fakeAdminNotifier = new FakeAdminNotifier();

            Staff supervisor = new Supervisor(fakeReportGenerator, fakeAdminNotifier);
            // Act
            supervisor.GenerateReport("Supervisor");

            // Assert 
            Assert.IsNull(fakeAdminNotifier.theMessage);
        }

        [Test]
        public void Supervisor_GenerateReport_Works_Throws_Excetpion()
        {   // Arrange
            FakeReportGenerator stubReportGenerator = new FakeReportGenerator();
            FakeReportGenerator fakeReportGenerator = new FakeReportGenerator();
            FakeAdminNotifier fakeAdminNotifier = new FakeAdminNotifier();
            stubReportGenerator.WillThrow = new Exception("fake exception");
            Staff supervisor = new Supervisor(stubReportGenerator, fakeAdminNotifier);
            // Act
            supervisor.GenerateReport("Supervisor");
            // Assert 
            StringAssert.Contains("Error Supervisor Report Generation fake exception", fakeAdminNotifier.theMessage);
            Assert.IsNull(fakeReportGenerator.staffType);
        }

    }

internal class FakeAdminNotifier : IAdminNotifier
    {
        public Exception WillThrow = null;
        public string theMessage = null;
        public void AdminNotification(string exception_context)
        {
            theMessage = exception_context;

        }
    }

    internal class FakeDatabaseUtility : IInsert, IRead
    {
        public Exception WillThrow = null;
        public string theMessage = null;
        public int staffId = -1;

        public void Insert(string content)
        {
            theMessage = content;
            if (WillThrow != null)
            { throw WillThrow; }
        }

        public void Read(int Staff_id)
        {
            staffId = Staff_id;
            if (WillThrow != null)
            { throw WillThrow; }
        }
    }

    internal class FakeReportGenerator : IReportGenerator
    {
        public string staffType = null;
        public Exception WillThrow = null;
        public string GeneragingReport(string Staff_Type)
        {
            staffType = Staff_Type;
            if (WillThrow != null)
            {
                throw WillThrow;
            }
            return staffType;
        }
    }
}
